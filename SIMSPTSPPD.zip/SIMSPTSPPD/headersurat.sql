-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2024 at 11:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkl20232`
--

-- --------------------------------------------------------

--
-- Table structure for table `headersurat`
--

CREATE TABLE `headersurat` (
  `IdSurat` int(11) NOT NULL,
  `NomorSurat` varchar(50) NOT NULL,
  `SifatSurat` varchar(30) DEFAULT NULL,
  `Lampiran` varchar(30) DEFAULT NULL,
  `Perihal` text DEFAULT NULL,
  `TglSurat` datetime NOT NULL DEFAULT current_timestamp(),
  `TujuanSurat` text NOT NULL,
  `TanggalAwal` datetime NOT NULL DEFAULT current_timestamp(),
  `TanggalAkhir` datetime NOT NULL DEFAULT current_timestamp(),
  `TempatKegiatan` text NOT NULL,
  `AcaraKegiatan` text NOT NULL,
  `AlatAngkutan` varchar(20) DEFAULT NULL,
  `ValidasiSPPDKabag` tinyint(1) DEFAULT 0,
  `ValidasiSPTKabag` tinyint(1) NOT NULL DEFAULT 0,
  `ValidasiSPTSekwan` tinyint(1) NOT NULL DEFAULT 0,
  `ValidasiSPTKetua` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `headersurat`
--

INSERT INTO `headersurat` (`IdSurat`, `NomorSurat`, `SifatSurat`, `Lampiran`, `Perihal`, `TglSurat`, `TujuanSurat`, `TanggalAwal`, `TanggalAkhir`, `TempatKegiatan`, `AcaraKegiatan`, `AlatAngkutan`, `ValidasiSPPDKabag`, `ValidasiSPTKabag`, `ValidasiSPTSekwan`, `ValidasiSPTKetua`) VALUES
(8, '172/10/KOMISI.III/DPRD/2024', 'Penting', 'Satu Lampiran', '', '0000-00-00 00:00:00', 'bapak. heru susanto', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '', 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `headersurat`
--
ALTER TABLE `headersurat`
  ADD PRIMARY KEY (`IdSurat`),
  ADD KEY `NomorSurat` (`NomorSurat`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `headersurat`
--
ALTER TABLE `headersurat`
  MODIFY `IdSurat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
