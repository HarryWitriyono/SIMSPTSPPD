<?php
		include('koneksi.db.php');
		if (isset($_GET['idSurat'])){
			$NomorSurat=filter_var($_GET['idSurat'],FILTER_SANITIZE_STRING);
			$sql="SELECT * FROM `headersurat` WHERE idSurat='".$NomorSurat."'";
			$q=mysqli_query($koneksi, $sql);
			$r=mysqli_fetch_array($q);
		} 
			?>
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
            table tr td{
                font-size: 13px;
            }
            table tr .text{
                text-align: right;
                font-size: 13px;
            }
        </style>
    </head>
    <body>
        <center>
            <table>
                <tr>
                    <td><img src="images/Logo.png" width="80" height="85"></td>
                    <td>
                        <center>
                            <font size="5" style="font-family: time new romance;"><b>DEWAN PERWAKILAN RAKYAT DAERAH</b>
                            </font><br>
                            <font size="5"><b>KOTA BENGKULU</b></font><br>
                            <font size="2"><i>JL. WR. Supratman Kel. Bentiring Permai Telp. 
                                (0736) 7310026-7310454-7310455 Fax 7310026</i></font><br> 
                            <font size="3" style="font-family: time new romance;"><b>BENGKULU</b></font><br>
                        </center>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><hr></td>
                </tr>
            </table><center>
            <table width="614">
                <tr>
                    <td>
                        <center>
                            <font size="4" style="font-family: 'Times New Roman', Times, serif;"><u><b>SURAT PERINTAH TUGAS</b></u></font><br>
                            <font size="3" style="font-family: 'Times New Roman', Times, serif;">Nomor  : <input type="text" name="no_surat_1" style="font-size: 12px; font-family: time new romance; width: 100px;">
                        </center>
                    </td>
                </tr>
            </table>
            <table width="614">
                <p style="text-align: left;">1.	Dasar		: <br>
                    &emsp;&emsp;&emsp;&emsp;1.	Peraturan Walikota Bengkulu Nomor 32 Tahun 2022 Tentang Perjalanan Dinas Pemerintah<br>
                    &emsp; &emsp; &emsp; &emsp; Kota Bengkulu Tahun Anggaran 2023.<br>
                    &emsp;&emsp;&emsp;&emsp;2.	Pengajuan dari Anggota DPRD Kota Bengkulu Tanggal 05 September 2023  Perihal<br>
                    &emsp; &emsp; &emsp; &emsp; Permohonan Kunjungan Kerja<br>
                    &emsp;&emsp;&emsp;&emsp;3.	Persetujuan Ketua DPRD  Kota Bengkulu tanggal 05 Setember  2023<br>
                
                </p>
            <center>
                <font size="3" style="font-family: 'Times New Roman', Times, serif;"><b>MEMERINTAHKAN</b></font>
            </center>
<p style="text-align: left;">
2.	Kepada	: Nama / NIP / Jabatan<br>
&emsp;&emsp;&emsp;&emsp;
<table><tr><td>
<ol>
                <?php $sqlps="select ps.*,p.nama_lengkap from pesertakegiatan ps inner join pengguna p ON ps.id_login = p.id_login where ps.idSurat='".$r['IdSurat']."' and p.idlevel <>'5'";
                $qps=mysqli_query($koneksi,$sqlps);
                $rps=mysqli_fetch_array($qps);
                if (!empty($rps)) {
                    do {
                        echo "<li>".$rps['nama_lengkap'];
                        echo "</li>";
                    } while($rps=mysqli_fetch_array($qps));
                }
                ?>
                </ol>
            </td></tr></table>                
<br>
3.	Untuk 		:<br>
&emsp;&emsp;&emsp;&emsp;<textarea rows="5" cols="30" name="kepada"></textarea><br><br>
4.	Tanggal	:<input style="font-size: 12px; font-family: time new romance; width: 100px;" id="TglAwal" name="TglAwal" type="text" class="form-control"> S/d 
<input style="font-size: 12px; font-family: time new romance; width: 100px;" id="TglAkhir" name="TglAkhir" type="text" class="form-control">
<br>
5.	Keterangan	:<br>
&emsp;&emsp;&emsp;&emsp;1.	Untuk dilaksanakan dengan penuh rasa tanggung jawab.<br>
&emsp;&emsp;&emsp;&emsp;2.	Membuat laporan tertulis dan tindak lanjut atas  pelaksanaan tugas tersebut.<br>
</p>
            </table>
            <br>
            
            <br>
            
        </center>
        <table width="200">
            <p style="text-align: right;">
                
                    Ditetapkan di Bengkulu&emsp;&emsp;<br>
                Pada Tanggal, <input style="font-size: 12px; font-family: time new romance; width: 100px;" id="TglsSurat" name="TglSurat" type="text" class="form-control"><br>
                Ketua DPRD Kota Bengkulu&emsp;<br><br><br><br><br>
                <font size="3" style="font-family: 'Times New Roman', Times, serif;"><b><u>SUPRIANTO, S.IP.</u></b></font>
                &emsp;&emsp;&emsp13;
            </p>
        </table>
    </body>
</html>