<html>

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 15 (filtered)">
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Palladio Uralic";}
@font-face
	{font-family:"Liberation Sans Narrow";}
@font-face
	{font-family:Carlito;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	text-autospace:none;
	font-size:11.0pt;
	font-family:"Tahoma",sans-serif;}
p.MsoBodyText, li.MsoBodyText, div.MsoBodyText
	{margin:0cm;
	text-autospace:none;
	font-size:9.0pt;
	font-family:"Palladio Uralic";}
p.TableParagraph, li.TableParagraph, div.TableParagraph
	{mso-style-name:"Table Paragraph";
	margin:0cm;
	text-autospace:none;
	font-size:11.0pt;
	font-family:"Tahoma",sans-serif;}
.MsoPapDefault
	{text-autospace:none;}
@page WordSection1
	{size:612.0pt 1008.0pt;
	margin:28.0pt 35.0pt 14.0pt 29.0pt;}
div.WordSection1
	{page:WordSection1;}
@page WordSection2
	{size:612.0pt 1008.0pt;
	margin:57.0pt 35.0pt 14.0pt 29.0pt;}
div.WordSection2
	{page:WordSection2;}
@page WordSection3
	{size:612.0pt 1008.0pt;
	margin:28.0pt 35.0pt 14.0pt 29.0pt;}
div.WordSection3
	{page:WordSection3;}
@page WordSection4
	{size:612.0pt 1008.0pt;
	margin:28.0pt 35.0pt 14.0pt 29.0pt;}
div.WordSection4
	{page:WordSection4;}
-->
</style>

</head>

<body lang=EN-ID style='word-wrap:break-word'>

<div class=WordSection1>

<p class=MsoBodyText style='margin-top:.3pt'><span lang=id style='font-size:
1.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='margin-left:5.8pt;border-collapse:collapse'>
 <tr style='height:13.75pt'>
  <td width=716 valign=top style='width:537.0pt;padding:0cm 0cm 0cm 0cm;
  height:13.75pt'>
  <p class=TableParagraph align=center style='margin-top:.15pt;margin-right:
  .35pt;margin-bottom:0cm;margin-left:42.25pt;margin-bottom:.0001pt;text-align:
  center;line-height:12.6pt'><b><span lang=id style='font-size:11.5pt'>PEMERINTAH<span
  style='letter-spacing:.25pt'> </span>DAERAH<span style='letter-spacing:.3pt'>
  </span>KOTA<span style='letter-spacing:.25pt'> </span><span style='letter-spacing:
  -.1pt'>BENGKULU</span></span></b></p>
  </td>
 </tr>
 <tr style='height:14.75pt'>
  <td width=716 valign=top style='width:537.0pt;padding:0cm 0cm 0cm 0cm;
  height:14.75pt'>
  <p class=TableParagraph align=center style='margin-top:0cm;margin-right:.4pt;
  margin-bottom:0cm;margin-left:42.25pt;margin-bottom:.0001pt;text-align:center;
  line-height:13.8pt'><span style='position:relative;z-index:-1660084736'><span
  style='left:0px;position:absolute;left:9px;top:-19px;width:51px;height:59px'><img
  width=51 height=59
  src="SPT%20DAN%20SPPD%20PERJADIN%20DEWAN%201_files/image001.gif"></span></span><b><span
  lang=id style='font-size:13.0pt;font-family:"Liberation Sans Narrow",sans-serif'>SEKRETARIAT<span
  style='letter-spacing:1.35pt'> </span>DEWAN<span style='letter-spacing:1.35pt'>
  </span>PERWAKILAN<span style='letter-spacing:1.35pt'> </span>RAKYAT<span
  style='letter-spacing:1.35pt'> </span><span style='letter-spacing:-.1pt'>DAERAH</span></span></b></p>
  </td>
 </tr>
 <tr style='height:14.35pt'>
  <td width=716 valign=top style='width:537.0pt;padding:0cm 0cm 0cm 0cm;
  height:14.35pt'>
  <p class=TableParagraph align=center style='margin-left:42.25pt;text-align:
  center;line-height:13.1pt'><b><span lang=id style='font-size:11.5pt;
  font-family:"Liberation Sans Narrow",sans-serif'>KOTA<span style='letter-spacing:
  .15pt'> </span><span style='letter-spacing:-.1pt'>BENGKULU</span></span></b></p>
  </td>
 </tr>
 <tr style='height:13.15pt'>
  <td width=716 valign=top style='width:537.0pt;border:none;border-bottom:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.15pt'>
  <p class=TableParagraph align=center style='margin-top:1.45pt;margin-right:
  .5pt;margin-bottom:0cm;margin-left:42.25pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:8.0pt;font-family:"Liberation Sans Narrow",sans-serif'>Jl.<span
  style='letter-spacing:.4pt'> </span>WR.<span style='letter-spacing:.45pt'> </span>Supratman<span
  style='letter-spacing:.35pt'> </span>Kel.<span style='letter-spacing:.4pt'> </span>Bentiring<span
  style='letter-spacing:.35pt'> </span>Telp.<span style='letter-spacing:.45pt'>
  </span>(0736)<span style='letter-spacing:.4pt'> </span>7310026-7310454<span
  style='letter-spacing:.35pt'> </span>Fax.7310450<span style='letter-spacing:
  .3pt'> </span>Kota<span style='letter-spacing:.35pt'> </span><span
  style='letter-spacing:-.1pt'>Bengkulu</span></span></p>
  </td>
 </tr>
</table>

<p class=MsoBodyText><span lang=id style='font-size:10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:3.25pt'><span lang=id style='font-size:
10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='margin-left:180.35pt;border-collapse:collapse'>
 <tr style='height:13.55pt'>
  <td width=252 valign=top style='width:188.7pt;padding:0cm 0cm 0cm 0cm;
  height:13.55pt'>
  <p class=TableParagraph align=center style='margin-top:.1pt;text-align:center;
  line-height:12.45pt'><b><span lang=id style='font-size:11.5pt;font-family:
  "Liberation Sans Narrow",sans-serif'>SURAT<span style='letter-spacing:.25pt'>
  </span>PERINTAH<span style='letter-spacing:.15pt'> </span>PERJALANAN<span
  style='letter-spacing:.2pt'> </span><span style='letter-spacing:-.2pt'>DINAS</span></span></b></p>
  </td>
 </tr>
 <tr style='height:13.55pt'>
  <td width=252 valign=top style='width:188.7pt;padding:0cm 0cm 0cm 0cm;
  height:13.55pt'>
  <p class=TableParagraph align=center style='margin-top:.3pt;text-align:center;
  line-height:12.25pt'><b><span lang=id style='font-size:11.5pt;font-family:
  "Liberation Sans Narrow",sans-serif'>( S P<span style='letter-spacing:.05pt'>
  </span>P D <span style='letter-spacing:-.5pt'>)</span></span></b></p>
  </td>
 </tr>
</table>

<p class=MsoBodyText><span lang=id style='font-size:10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:2.55pt'><span lang=id style='font-size:
10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoNormalTable border=1 cellspacing=0 cellpadding=0
 style='margin-left:6.05pt;border-collapse:collapse;border:none'>
 <tr style='height:15.2pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.2pt'>
  <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
  .15pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>1.</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border:solid black 1.0pt;
  border-left:none;padding:0cm 0cm 0cm 0cm;height:15.2pt'>
  <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Pejabat<span style='letter-spacing:-.45pt'> </span>berwenang<span
  style='letter-spacing:-.4pt'> </span>yang<span style='letter-spacing:-.45pt'>
  </span>memberi<span style='letter-spacing:-.4pt'> </span><span
  style='letter-spacing:-.1pt'>perintah</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:solid black 1.0pt;
  border-left:none;padding:0cm 0cm 0cm 0cm;height:15.2pt'>
  <p class=TableParagraph style='margin-top:.95pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:1.65pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Sekretaris<span style='letter-spacing:-.5pt'> </span>DPRD<span
  style='letter-spacing:-.5pt'> </span>Kota<span style='letter-spacing:-.4pt'> </span><span
  style='letter-spacing:-.1pt'>Bengkulu</span></span></p>
  </td>
 </tr>
 <tr style='height:17.55pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:17.55pt'>
  <p class=TableParagraph align=center style='margin-top:2.15pt;margin-right:
  .15pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>2.</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:17.55pt'>
  <p class=TableParagraph style='margin-top:2.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Nama/NIP<span style='letter-spacing:-.45pt'> </span>Pegawai<span
  style='letter-spacing:-.4pt'> </span>yang<span style='letter-spacing:-.4pt'> </span><span
  style='letter-spacing:-.1pt'>diperintahkan</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:17.55pt'>
  <p class=TableParagraph style='margin-top:2.25pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:1.65pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>SUDISMAN,<span style='letter-spacing:-.55pt'> </span>S.<span
  style='letter-spacing:-.55pt'> </span><span style='letter-spacing:-.25pt'>Sos</span></span></p>
  </td>
 </tr>
 <tr style='height:15.8pt'>
  <td width=30 rowspan=4 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:15.8pt'>
  <p class=TableParagraph align=center style='margin-top:0cm;margin-right:.7pt;
  margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:center;
  line-height:11.95pt'><span lang=id style='font-size:10.0pt;letter-spacing:
  -.5pt'>3</span></p>
  </td>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:15.8pt'>
  <p class=TableParagraph align=center style='margin-top:2.4pt;margin-right:
  .25pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.8pt'>
  <p class=TableParagraph style='margin-top:1.9pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Pangkat<span style='letter-spacing:-.35pt'> </span>dan<span
  style='letter-spacing:-.4pt'> </span>golongan<span style='letter-spacing:
  -.4pt'> </span>ruang<span style='letter-spacing:-.35pt'> </span><span
  style='letter-spacing:-.2pt'>gaji</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.8pt'>
  <p class=TableParagraph style='margin-top:2.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
 </tr>
 <tr style='height:13.9pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:13.9pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.9pt'>
  <p class=TableParagraph style='margin-top:1.3pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt;line-height:11.65pt'><span
  lang=id style='font-size:10.0pt'>menurut<span style='letter-spacing:-.35pt'> </span>PP<span
  style='letter-spacing:-.25pt'> </span>No.<span style='letter-spacing:-.3pt'> </span>6<span
  style='letter-spacing:-.35pt'> </span>Tahun<span style='letter-spacing:-.35pt'>
  </span><span style='letter-spacing:-.2pt'>1997</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.9pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:16.6pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:16.6pt'>
  <p class=TableParagraph align=center style='margin-top:.5pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:16.6pt'>
  <p class=TableParagraph style='margin-top:1.25pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Jabatan<span style='letter-spacing:-.35pt'> </span><span
  style='letter-spacing:-.1pt'>Instansi</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:16.6pt'>
  <p class=TableParagraph style='margin-top:1.25pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
 </tr>
 <tr style='height:23.4pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;border-bottom:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:23.4pt'>
  <p class=TableParagraph align=center style='margin-top:3.75pt;margin-right:
  .9pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>c.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:23.4pt'>
  <p class=TableParagraph style='margin-top:3.25pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Tingkat<span style='letter-spacing:-.6pt'> </span>menurut<span
  style='letter-spacing:-.6pt'> </span>peraturan<span style='letter-spacing:
  -.55pt'> </span>perjalanan<span style='letter-spacing:-.6pt'> </span><span
  style='letter-spacing:-.2pt'>Dinas</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:23.4pt'>
  <p class=TableParagraph style='margin-top:3.75pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>c.</span></p>
  </td>
 </tr>
 <tr style='height:89.25pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:89.25pt'>
  <p class=TableParagraph align=center style='margin-left:1.65pt;text-align:
  center;line-height:11.95pt'><span lang=id style='font-size:10.0pt;letter-spacing:
  -.5pt'>4</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:89.25pt'>
  <p class=TableParagraph style='margin-top:1.2pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:1.75pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Maksud<span style='letter-spacing:-.55pt'> </span>Perjalanan<span
  style='letter-spacing:-.5pt'> </span><span style='letter-spacing:-.2pt'>Dinas</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:89.25pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:16.35pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:16.35pt'>
  <p class=TableParagraph align=center style='margin-top:2.0pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>5</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:16.35pt'>
  <p class=TableParagraph style='margin-top:1.55pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Alat<span style='letter-spacing:-.35pt'> </span>angkutan<span
  style='letter-spacing:-.4pt'> </span>yang<span style='letter-spacing:-.3pt'> </span><span
  style='letter-spacing:-.1pt'>dipergunakan</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:16.35pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:18.0pt'>
  <td width=30 rowspan=2 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:18.0pt'>
  <p class=TableParagraph align=center style='margin-top:1.2pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>6</span></p>
  </td>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:18.0pt'>
  <p class=TableParagraph align=center style='margin-top:1.2pt;margin-right:
  .25pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:18.0pt'>
  <p class=TableParagraph style='margin-top:1.2pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Tempat<span style='letter-spacing:-.4pt'> </span><span
  style='letter-spacing:-.1pt'>berangkat</span></span></p>
  </td>
  <td width=372 rowspan=2 valign=top style='width:278.85pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:18.0pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:25.05pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;border-bottom:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:25.05pt'>
  <p class=TableParagraph align=center style='margin-top:4.7pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:25.05pt'>
  <p class=TableParagraph style='margin-top:4.7pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Tempat<span style='letter-spacing:-.4pt'> </span><span
  style='letter-spacing:-.1pt'>tujuan</span></span></p>
  </td>
 </tr>
 <tr style='height:14.95pt'>
  <td width=30 rowspan=3 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:14.95pt'>
  <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>7</span></p>
  </td>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:14.95pt'>
  <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
  .25pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.95pt'>
  <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Lamanya<span style='letter-spacing:-.6pt'> </span>perjalanan<span
  style='letter-spacing:-.65pt'> </span><span style='letter-spacing:-.1pt'>dinas</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.95pt'>
  <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
 </tr>
 <tr style='height:14.85pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:14.85pt'>
  <p class=TableParagraph align=center style='margin-top:1.4pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.85pt'>
  <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Tanggal<span style='letter-spacing:-.5pt'> </span><span
  style='letter-spacing:-.1pt'>berangkat</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.85pt'>
  <p class=TableParagraph style='margin-top:1.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
 </tr>
 <tr style='height:15.1pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;border-bottom:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.1pt'>
  <p class=TableParagraph align=center style='margin-top:1.35pt;margin-right:
  .9pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>c.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.1pt'>
  <p class=TableParagraph style='margin-top:1.35pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Tanggal<span style='letter-spacing:-.45pt'> </span>harus<span
  style='letter-spacing:-.45pt'> </span><span style='letter-spacing:-.1pt'>kembali</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.1pt'>
  <p class=TableParagraph style='margin-top:1.35pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.25pt'>c.</span></p>
  </td>
 </tr>
 <tr style='height:14.55pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:14.55pt'>
  <p class=TableParagraph align=center style='margin-top:1.2pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>8</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.55pt'>
  <p class=TableParagraph style='margin-top:1.2pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Nama<span style='letter-spacing:-.45pt'> </span>Pengikut<span
  style='letter-spacing:-.4pt'> </span><span style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:14.55pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:12.85pt'>
  <td width=30 rowspan=3 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:12.85pt'>
  <p class=TableParagraph align=center style='margin-top:.35pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>9</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border:none;
  border-right:solid black 1.0pt;padding:0cm 0cm 0cm 0cm;height:12.85pt'>
  <p class=TableParagraph style='margin-top:.2pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt;line-height:11.65pt'><span
  lang=id style='font-size:10.0pt'>Pembebanan<span style='letter-spacing:-.7pt'>
  </span><span style='letter-spacing:-.1pt'>Anggaran</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:12.85pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
 <tr style='height:13.25pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:13.25pt'>
  <p class=TableParagraph align=center style='margin-top:.5pt;margin-right:
  .25pt;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center;line-height:11.75pt'><span lang=id style='font-size:10.0pt;letter-spacing:
  -.25pt'>a.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.25pt'>
  <p class=TableParagraph style='margin-top:.5pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt;line-height:11.75pt'><span
  lang=id style='font-size:10.0pt;letter-spacing:-.1pt'>Instansi</span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.25pt'>
  <p class=TableParagraph style='margin-top:.5pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt;line-height:11.75pt'><span
  lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>a.</span></p>
  </td>
 </tr>
 <tr style='height:13.45pt'>
  <td width=23 valign=top style='width:17.1pt;border:none;border-bottom:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.45pt'>
  <p class=TableParagraph align=center style='margin-top:.65pt;margin-right:
  0cm;margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:
  center;line-height:11.8pt'><span lang=id style='font-size:10.0pt;letter-spacing:
  -.25pt'>b.</span></p>
  </td>
  <td width=291 valign=top style='width:218.35pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.45pt'>
  <p class=TableParagraph style='margin-top:.65pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt;line-height:11.8pt'><span
  lang=id style='font-size:10.0pt'>Rekening<span style='letter-spacing:-.55pt'>
  </span><span style='letter-spacing:-.1pt'>Anggaran</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:13.45pt'>
  <p class=TableParagraph style='margin-top:.65pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:7.9pt;margin-bottom:.0001pt;line-height:11.8pt'><span
  lang=id style='font-size:10.0pt;letter-spacing:-.25pt'>b.</span></p>
  </td>
 </tr>
 <tr style='height:15.75pt'>
  <td width=30 valign=top style='width:22.7pt;border:solid black 1.0pt;
  border-top:none;padding:0cm 0cm 0cm 0cm;height:15.75pt'>
  <p class=TableParagraph align=center style='margin-top:0cm;margin-right:.15pt;
  margin-bottom:0cm;margin-left:1.65pt;margin-bottom:.0001pt;text-align:center;
  line-height:11.95pt'><span lang=id style='font-size:10.0pt;letter-spacing:
  -.25pt'>10</span></p>
  </td>
  <td width=314 colspan=2 valign=top style='width:235.45pt;border-top:none;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.75pt'>
  <p class=TableParagraph style='margin-top:1.8pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:4.85pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>Keterangan<span style='letter-spacing:-.75pt'> </span>lain-<span
  style='letter-spacing:-.2pt'>lain</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:15.75pt'>
  <p class=TableParagraph><span lang=id style='font-size:10.0pt;font-family:
  "Times New Roman",serif'>&nbsp;</span></p>
  </td>
 </tr>
</table>

<p class=MsoBodyText style='margin-top:.4pt'><span lang=id style='font-size:
8.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='margin-left:305.5pt;border-collapse:collapse'>
 <tr style='height:14.05pt'>
  <td width=100 valign=top style='width:74.65pt;padding:0cm 0cm 0cm 0cm;
  height:14.05pt'>
  <p class=TableParagraph align=center style='margin-top:0cm;margin-right:.05pt;
  margin-bottom:0cm;margin-left:.05pt;margin-bottom:.0001pt;text-align:center;
  line-height:12.05pt'><span lang=id style='font-size:10.0pt'>Dikeluarkan<span
  style='letter-spacing:-.4pt'> </span>di<span style='letter-spacing:-.35pt'> </span><span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=153 valign=top style='width:114.95pt;padding:0cm 0cm 0cm 0cm;
  height:14.05pt'>
  <p class=TableParagraph style='margin-top:.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:2.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt;letter-spacing:-.1pt'>Bengkulu</span></p>
  </td>
 </tr>
 <tr style='height:17.2pt'>
  <td width=100 valign=top style='width:74.65pt;padding:0cm 0cm 0cm 0cm;
  height:17.2pt'>
  <p class=TableParagraph align=center style='margin-top:1.5pt;margin-right:
  .05pt;margin-bottom:0cm;margin-left:0cm;margin-bottom:.0001pt;text-align:
  center'><span lang=id style='font-size:10.0pt'>Pada<span style='letter-spacing:
  -.25pt'> </span>Tanggal<span style='letter-spacing:2.75pt'> </span><span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=153 valign=top style='width:114.95pt;padding:0cm 0cm 0cm 0cm;
  height:17.2pt'>
  <p class=TableParagraph style='margin-top:1.5pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:36.9pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  10.0pt'>September<span style='letter-spacing:2.4pt'> </span><span
  style='letter-spacing:-.2pt'>2023</span></span></p>
  </td>
 </tr>
 <tr style='height:14.65pt'>
  <td width=253 colspan=2 valign=top style='width:189.6pt;padding:0cm 0cm 0cm 0cm;
  height:14.65pt'>
  <p class=TableParagraph style='margin-top:3.75pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:30.55pt;margin-bottom:.0001pt;line-height:9.9pt'><span
  lang=id style='font-size:9.0pt'>Sekretaris<span style='letter-spacing:.1pt'> </span>DPRD<span
  style='letter-spacing:.05pt'> </span>Kota<span style='letter-spacing:.1pt'> </span><span
  style='letter-spacing:-.1pt'>Bengkulu</span></span></p>
  </td>
 </tr>
</table>

<p class=MsoBodyText><span lang=id style='font-size:10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoBodyText><span lang=id style='font-size:10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:8.65pt'><span lang=id style='font-size:
10.0pt;font-family:"Times New Roman",serif'>&nbsp;</span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='margin-left:354.95pt;border-collapse:collapse'>
 <tr style='height:12.0pt'>
  <td width=117 valign=top style='width:87.85pt;padding:0cm 0cm 0cm 0cm;
  height:12.0pt'>
  <p class=TableParagraph style='margin-left:5.5pt;line-height:11.0pt'><b><u><span
  lang=id style='font-size:10.0pt;font-family:"Liberation Sans Narrow",sans-serif;
  letter-spacing:-.5pt'>(</span></u></b><b><span lang=id style='font-size:10.0pt;
  font-family:"Liberation Sans Narrow",sans-serif'>........................ <u><span
  style='letter-spacing:-.5pt'>)</span></u></span></b></p>
  </td>
 </tr>
 <tr style='height:12.7pt'>
  <td width=117 valign=top style='width:87.85pt;padding:0cm 0cm 0cm 0cm;
  height:12.7pt'>
  <p class=TableParagraph style='margin-top:.5pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:3.9pt;margin-bottom:.0001pt;line-height:11.2pt'><span
  lang=id style='font-size:10.0pt;font-family:"Liberation Sans Narrow",sans-serif'>Pembina<span
  style='letter-spacing:-.5pt'> </span>Utama<span style='letter-spacing:-.55pt'>
  </span><span style='letter-spacing:-.2pt'>Muda</span></span></p>
  </td>
 </tr>
 <tr style='height:9.95pt'>
  <td width=117 valign=top style='width:87.85pt;padding:0cm 0cm 0cm 0cm;
  height:9.95pt'>
  <p class=TableParagraph style='margin-top:.7pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:2.5pt;margin-bottom:.0001pt;line-height:8.25pt'><span
  lang=id style='font-size:8.0pt;font-family:"Arial",sans-serif;letter-spacing:
  -.2pt'>NIP.</span></p>
  </td>
 </tr>
</table>

</div>

<span lang=id style='font-size:8.0pt;font-family:"Arial",sans-serif'><br
clear=all style='page-break-before:always'>
</span>

<div class=WordSection2>

<p class=MsoBodyText style='margin-top:3.8pt;margin-right:0cm;margin-bottom:
0cm;margin-left:286.65pt;margin-bottom:.0001pt'><span lang=id style='font-family:
"Tahoma",sans-serif'>SPPD<span style='letter-spacing:.15pt'> </span><span
style='letter-spacing:-.25pt'>No</span>���������������� :<span
style='letter-spacing:3.3pt'> </span><span style='letter-spacing:-.2pt'>090/</span>����� <span
style='letter-spacing:-.1pt'>/SPPD.DPRD/SETWAN/2023</span></span></p>

<p class=MsoBodyText style='margin-top:2.95pt;margin-right:0cm;margin-bottom:
0cm;margin-left:286.65pt;margin-bottom:.0001pt'><span lang=id style='font-family:
"Tahoma",sans-serif'>Berangkat<span style='letter-spacing:.1pt'> </span><span
style='letter-spacing:-.2pt'>dari</span>�������� <span style='letter-spacing:
-.5pt'>:</span></span></p>

<p class=MsoBodyText style='margin-top:4.15pt;margin-right:0cm;margin-bottom:
0cm;margin-left:286.65pt;margin-bottom:.0001pt'><span lang=id style='font-family:
"Tahoma",sans-serif'>Pada<span style='letter-spacing:.2pt'> </span><span
style='letter-spacing:-.1pt'>tanggal</span>���������� <span style='letter-spacing:
-.5pt'>:</span></span></p>

<p class=MsoNormal style='margin-top:1.45pt;margin-right:0cm;margin-bottom:
0cm;margin-left:286.65pt;margin-bottom:.0001pt'><span lang=id style='font-size:
9.0pt;position:relative;top:-1.0pt;letter-spacing:-.25pt'>Ke</span><span
lang=id style='font-size:9.0pt;position:relative;top:-1.0pt'>������������������������ </span><span
lang=id style='font-size:10.0pt;letter-spacing:-.5pt'>:</span></p>

<p class=MsoNormal><span lang=id style='font-size:10.0pt'>&nbsp;</span></p>

<p class=MsoNormal><span lang=id style='font-size:10.0pt'>&nbsp;</span></p>

<p class=MsoNormal><span lang=id style='font-size:10.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='margin-top:2.7pt;margin-right:0cm;margin-bottom:.05pt;
margin-left:0cm'><span lang=id style='font-size:10.0pt'>&nbsp;</span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='margin-left:5.8pt;border-collapse:collapse'>
 <tr style='height:74.55pt'>
  <td width=344 valign=top style='width:258.1pt;border-top:solid black 1.0pt;
  border-left:none;border-bottom:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:74.55pt'>
  <p class=TableParagraph style='margin-top:0cm;margin-right:152.25pt;
  margin-bottom:0cm;margin-left:24.45pt;margin-bottom:.0001pt;text-indent:-22.7pt;
  line-height:110%'><span lang=id style='font-size:9.0pt;line-height:110%;
  letter-spacing:-.2pt'>II.</span><span lang=id style='font-size:9.0pt;
  line-height:110%'>��� Tiba di������������������������� <span
  style='letter-spacing:-.5pt'>: </span>Pada<span style='letter-spacing:.2pt'> </span><span
  style='letter-spacing:-.1pt'>tanggal</span>������������������������� <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-left:24.45pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.1pt'>Kepala</span><span lang=id
  style='font-size:9.0pt'>��������������� <span style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-top:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:74.55pt'>
  <p class=TableParagraph style='margin-left:22.6pt;line-height:10.4pt'><span
  lang=id style='font-size:9.0pt'>Berangkat<span style='letter-spacing:.1pt'> </span><span
  style='letter-spacing:-.2pt'>dari</span>�������� <span style='letter-spacing:
  -.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.1pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.25pt'>Ke</span><span lang=id style='font-size:9.0pt'>������������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt'>Pada<span style='letter-spacing:.2pt'> </span><span style='letter-spacing:
  -.1pt'>Tanggal</span>��������� <span style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.1pt'>Kepala</span><span lang=id style='font-size:9.0pt'>������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
 </tr>
 <tr style='height:51.7pt'>
  <td width=344 valign=top style='width:258.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:51.7pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.5pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:.05pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.5pt'>(</span><span lang=id
  style='font-size:9.0pt;font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.1pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-bottom:
  solid black 1.0pt;padding:0cm 0cm 0cm 0cm;height:51.7pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.5pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:.05pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.5pt'>(</span><span lang=id style='font-size:9.0pt;
  font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.1pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
 </tr>
 <tr style='height:74.6pt'>
  <td width=344 valign=top style='width:258.1pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:74.6pt'>
  <p class=TableParagraph style='margin-top:0cm;margin-right:152.25pt;
  margin-bottom:0cm;margin-left:24.45pt;margin-bottom:.0001pt;text-indent:-22.7pt;
  line-height:110%'><span lang=id style='font-size:9.0pt;line-height:110%'>III.<span
  style='letter-spacing:4.0pt'> </span>Tiba di������������������������� <span
  style='letter-spacing:-.5pt'>: </span>Pada<span style='letter-spacing:.2pt'> </span><span
  style='letter-spacing:-.1pt'>tanggal</span>������������������������� <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-left:24.45pt;line-height:10.8pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.1pt'>Kepala</span><span
  lang=id style='font-size:9.0pt'>��������������� <span style='letter-spacing:
  -.5pt'>:</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:74.6pt'>
  <p class=TableParagraph style='margin-left:22.6pt;line-height:10.4pt'><span
  lang=id style='font-size:9.0pt'>Berangkat<span style='letter-spacing:.1pt'> </span><span
  style='letter-spacing:-.2pt'>dari</span>�������� <span style='letter-spacing:
  -.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.25pt'>Ke</span><span lang=id style='font-size:9.0pt'>������������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt'>Pada<span style='letter-spacing:.2pt'> </span><span style='letter-spacing:
  -.1pt'>Tanggal</span>��������� <span style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.1pt'>Kepala</span><span lang=id style='font-size:9.0pt'>������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
 </tr>
 <tr style='height:51.7pt'>
  <td width=344 valign=top style='width:258.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:51.7pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.5pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:.05pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.5pt'>(</span><span lang=id
  style='font-size:9.0pt;font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.1pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-bottom:
  solid black 1.0pt;padding:0cm 0cm 0cm 0cm;height:51.7pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.5pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:.05pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.5pt'>(</span><span lang=id style='font-size:9.0pt;
  font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.1pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
 </tr>
 <tr style='height:25.9pt'>
  <td width=344 valign=top style='width:258.1pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:25.9pt'>
  <p class=TableParagraph align=right style='margin-right:152.25pt;text-align:
  right'><span lang=id style='font-size:9.0pt;letter-spacing:-.25pt'>IV.</span><span
  lang=id style='font-size:9.0pt'>��� Tiba<span style='letter-spacing:.1pt'> </span><span
  style='letter-spacing:-.25pt'>di</span>������� <span style='letter-spacing:
  -.5pt'>:</span></span></p>
  <p class=TableParagraph align=right style='margin-top:1.9pt;margin-right:
  152.25pt;margin-bottom:0cm;margin-left:0cm;margin-bottom:.0001pt;text-align:
  right'><span lang=id style='font-size:9.0pt'>Pada<span style='letter-spacing:
  .2pt'> </span><span style='letter-spacing:-.1pt'>tanggal</span>������� <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:25.9pt'>
  <p class=TableParagraph style='margin-left:22.6pt'><span lang=id
  style='font-size:9.0pt'>Berangkat<span style='letter-spacing:.1pt'> </span><span
  style='letter-spacing:-.2pt'>dari</span>�������� <span style='letter-spacing:
  -.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.9pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.25pt'>Ke</span><span lang=id style='font-size:9.0pt'>������������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
 </tr>
 <tr style='height:53.75pt'>
  <td width=344 valign=top style='width:258.1pt;border:none;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:53.75pt'>
  <p class=TableParagraph style='margin-top:2.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.1pt'>Kepala</span><span lang=id
  style='font-size:9.0pt'>��������������� <span style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;padding:0cm 0cm 0cm 0cm;
  height:53.75pt'>
  <p class=TableParagraph style='margin-top:2.4pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt'>Pada<span style='letter-spacing:.2pt'> </span><span style='letter-spacing:
  -.1pt'>Tanggal</span>��������� <span style='letter-spacing:-.5pt'>:</span></span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
  9.0pt;letter-spacing:-.1pt'>Kepala</span><span lang=id style='font-size:9.0pt'>������������������ <span
  style='letter-spacing:-.5pt'>:</span></span></p>
  </td>
 </tr>
 <tr style='height:52.0pt'>
  <td width=344 valign=top style='width:258.1pt;border-top:none;border-left:
  none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  padding:0cm 0cm 0cm 0cm;height:52.0pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.85pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-left:24.45pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.5pt'>(</span><span lang=id
  style='font-size:9.0pt;font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:24.45pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
  <td width=372 valign=top style='width:278.85pt;border:none;border-bottom:
  solid black 1.0pt;padding:0cm 0cm 0cm 0cm;height:52.0pt'>
  <p class=TableParagraph><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-top:6.85pt'><span lang=id
  style='font-size:9.0pt'>&nbsp;</span></p>
  <p class=TableParagraph style='margin-left:22.6pt'><span lang=id
  style='font-size:9.0pt;letter-spacing:-.5pt'>(</span><span lang=id
  style='font-size:9.0pt;font-family:"Times New Roman",serif'>........................................................................ </span><span
  lang=id style='font-size:9.0pt;letter-spacing:-.5pt'>)</span></p>
  <p class=TableParagraph style='margin-top:1.15pt;margin-right:0cm;margin-bottom:
  0cm;margin-left:22.6pt;margin-bottom:.0001pt;line-height:10.45pt'><span
  lang=id style='font-size:9.0pt;letter-spacing:-.2pt'>NIP.</span></p>
  </td>
 </tr>
</table>

</div>

<span lang=id style='font-size:9.0pt;font-family:"Tahoma",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection3>

<p class=MsoBodyText align=right style='margin-top:4.3pt;text-align:right'><span
lang=id style='font-family:"Carlito",sans-serif;letter-spacing:-.2pt'>V.V.</span></p>

<span lang=id style='font-size:9.0pt;font-family:"Palladio Uralic"'><br
clear=all>
</span>

<p class=MsoBodyText style='margin-top:4.3pt;margin-right:0cm;margin-bottom:
0cm;margin-left:3.35pt;margin-bottom:.0001pt'><span lang=id style='font-family:
"Carlito",sans-serif'>Tiba<span style='letter-spacing:.05pt'> </span>Kembali<span
style='letter-spacing:.05pt'> </span><span style='letter-spacing:-.25pt'>di</span></span></p>

<p class=MsoBodyText style='margin-top:3.85pt;margin-right:0cm;margin-bottom:
0cm;margin-left:3.35pt;margin-bottom:.0001pt'><span lang=id>Pada<span
style='letter-spacing:.1pt'> </span><span style='letter-spacing:-.1pt'>tanggal</span></span></p>

<span lang=id style='font-size:11.0pt;font-family:"Tahoma",sans-serif'><br
clear=all>
</span>

<p class=MsoNormal style='margin-top:3.85pt;margin-right:0cm;margin-bottom:
0cm;margin-left:42.55pt;margin-bottom:.0001pt'><span lang=id style='font-size:
9.0pt'>:<span style='letter-spacing:.65pt'> </span></span><span lang=id
style='font-size:9.0pt;font-family:"Carlito",sans-serif;letter-spacing:-.1pt'>�������������..</span></p>

<p class=MsoNormal style='margin-top:4.05pt;margin-right:0cm;margin-bottom:
0cm;margin-left:43.6pt;margin-bottom:.0001pt'><span lang=id style='font-size:
9.0pt;font-family:"Palladio Uralic"'>:<span style='letter-spacing:1.1pt'> </span></span><span
lang=id style='font-size:9.0pt;font-family:"Carlito",sans-serif;letter-spacing:
-.1pt'>�������������..</span></p>

</div>

<span lang=id style='font-size:9.0pt;font-family:"Carlito",sans-serif'><br
clear=all style='page-break-before:auto'>
</span>

<div class=WordSection4>

<p class=MsoBodyText style='margin-top:.55pt'><span lang=id style='font-size:
2.0pt;font-family:"Carlito",sans-serif'>&nbsp;</span></p>

<p class=MsoBodyText style='margin-left:5.4pt;line-height:1.0pt'><span lang=id
style='font-size:1.0pt;font-family:"Carlito",sans-serif'><img width=716
height=1 id="Group 3"
src="SPT%20DAN%20SPPD%20PERJADIN%20DEWAN%201_files/image002.gif"></span></p>

<p class=MsoBodyText style='margin-top:.2pt;margin-right:0cm;margin-bottom:
0cm;margin-left:7.1pt;margin-bottom:.0001pt;line-height:110%'><span lang=id>Telah
diperiksa dengan keterangan bahwa perjalanan tersebut diatas benar dilakukan
atas perintahnya dan semata-mata untuk kepentingan jabatan dalam waktu yang
sesingkat-singkatnya</span></p>

<p class=MsoBodyText><span lang=id>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:3.55pt'><span lang=id>&nbsp;</span></p>

<p class=MsoBodyText style='margin-top:.05pt;margin-right:0cm;margin-bottom:
0cm;margin-left:353.5pt;margin-bottom:.0001pt'><span lang=id style='font-family:
"Tahoma",sans-serif'>Sekretaris<span style='letter-spacing:.1pt'> </span>DPRD<span
style='letter-spacing:.05pt'> </span>Kota<span style='letter-spacing:.1pt'> </span><span
style='letter-spacing:-.1pt'>Bengkulu</span></span></p>

<p class=MsoNormal><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>

<p class=MsoNormal><span lang=id style='font-size:9.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='margin-top:6.55pt'><span lang=id style='font-size:
9.0pt'>&nbsp;</span></p>

<p class=MsoNormal style='margin-left:374.0pt'><b><u><span lang=id
style='font-size:10.0pt;font-family:"Liberation Sans Narrow",sans-serif;
letter-spacing:-.5pt'>(</span></u></b><b><span lang=id style='font-size:10.0pt;
font-family:"Liberation Sans Narrow",sans-serif'>.......................... <u><span
style='letter-spacing:-.5pt'>)</span></u></span></b></p>

<p class=MsoNormal style='margin-top:2.35pt;margin-right:0cm;margin-bottom:
0cm;margin-left:373.3pt;margin-bottom:.0001pt'><span lang=id style='font-size:
10.0pt;font-family:"Liberation Sans Narrow",sans-serif'>Pembina<span
style='letter-spacing:-.5pt'> </span>Utama<span style='letter-spacing:-.55pt'> </span><span
style='letter-spacing:-.2pt'>Muda</span></span></p>

<p class=MsoNormal style='margin-top:1.4pt;margin-right:0cm;margin-bottom:0cm;
margin-left:374.5pt;margin-bottom:.0001pt'><span lang=id style='font-size:8.0pt;
font-family:"Arial",sans-serif;letter-spacing:-.2pt'>NIP.</span></p>

<p class=MsoBodyText style='margin-top:1.1pt'>

<table cellpadding=0 cellspacing=0 align=left>
 <tr>
  <td width=46 height=0></td>
 </tr>
 <tr>
  <td></td>
  <td><img width=716 height=1
  src="SPT%20DAN%20SPPD%20PERJADIN%20DEWAN%201_files/image002.gif"></td>
 </tr>
</table>

<br clear=ALL>
</p>

<p class=MsoNormal style='margin-top:.1pt;margin-right:0cm;margin-bottom:0cm;
margin-left:7.1pt;margin-bottom:.0001pt'><b><span lang=id style='font-size:
9.0pt;font-family:"Carlito",sans-serif'>VI.<span style='letter-spacing:.05pt'> </span>CATATAN<span
style='letter-spacing:.05pt'> </span>LAIN-<span style='letter-spacing:-.2pt'>LAIN</span></span></b></p>

<p class=MsoBodyText>

<table cellpadding=0 cellspacing=0 align=left>
 <tr>
  <td width=46 height=0></td>
 </tr>
 <tr>
  <td></td>
  <td><img width=716 height=1
  src="SPT%20DAN%20SPPD%20PERJADIN%20DEWAN%201_files/image002.gif"></td>
 </tr>
</table>

<br clear=ALL>
</p>

<p class=MsoNormal style='margin-top:3.8pt;margin-right:0cm;margin-bottom:0cm;
margin-left:7.1pt;margin-bottom:.0001pt'><b><span lang=id style='font-size:
9.0pt;font-family:"Palladio Uralic"'>VII.<span style='letter-spacing:.2pt'> </span>PERHATIAN<span
style='letter-spacing:.15pt'> </span><span style='letter-spacing:-.5pt'>:</span></span></b></p>

<p class=MsoBodyText style='margin-top:3.2pt;margin-right:2.25pt;margin-bottom:
0cm;margin-left:7.1pt;margin-bottom:.0001pt;line-height:110%'><span lang=id>Pejabat
Yang Berwenang menerbitkan SPPD, pegawai yang melakukan perjalanan dinas, para
pejabat yang mengesahkan tanggal berangkat/tiba, serta bendaharawan bertanggung
jawab berdasarkan peraturan-peraturan Keuangan Negara apabila Negara menderita
kerugian akibat kesalahan, kelalaian dan kealpaannya.</span></p>

</div>

</body>

</html>
