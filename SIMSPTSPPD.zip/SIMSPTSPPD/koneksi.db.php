<?php
	$host="localhost";
	$user="root";
	$pass="";
	$db="pkl20232";
	$koneksi=mysqli_connect($host,$user,$pass,$db) or die("gagal Connect");
?>